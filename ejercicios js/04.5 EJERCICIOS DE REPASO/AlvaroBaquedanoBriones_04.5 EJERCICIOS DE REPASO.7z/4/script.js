function calcularSalarioNeto() {
    var salarioBrutoAnual = document.getElementById("salario-bruto-anual").value;
    var salarioNetoMensual = salarioBrutoAnual / 12;
    document.getElementById("resultado").innerHTML = "<h2>Salario neto mensual:</h2><p>" + salarioNetoMensual.toFixed(2) + "</p>";
}