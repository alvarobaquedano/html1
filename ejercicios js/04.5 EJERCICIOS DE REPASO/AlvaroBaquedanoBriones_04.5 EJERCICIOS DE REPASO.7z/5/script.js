function mostrarTabla() {
    const numero = parseInt(document.getElementById("numero").value);
    let tablaHTML = "<ul>";
    for (let i = 1; i <= 10; i++) {
      tablaHTML += "<li>" + numero + " x " + i + " = " + (numero * i) + "</li>";
    }
    tablaHTML += "</ul>";
    document.getElementById("tabla").innerHTML = tablaHTML;
  }