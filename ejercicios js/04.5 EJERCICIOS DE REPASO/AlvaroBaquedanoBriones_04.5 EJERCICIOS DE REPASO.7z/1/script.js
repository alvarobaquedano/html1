function validarFormulario() {
	let nombre = document.forms["formulario"]["nombre"].value;
	let email = document.forms["formulario"]["email"].value;
	let comentarios = document.forms["formulario"]["comentarios"].value;
	let password = document.forms["formulario"]["password"].value;
	let errorMensaje = document.getElementById("mensaje-error");

	// Validar el campo nombre
	if (nombre == "") {
		errorMensaje.innerHTML = "El campo nombre es obligatorio";
		return false;
	} else {
		errorMensaje.innerHTML = "";
	}

	// Validar el campo email
	let comprobarMail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	if (!comprobarMail.test(email)) {
		errorMensaje.innerHTML = "El email no es válido";
		return false;
	} else {
		errorMensaje.innerHTML = "";
	}

	// Validar el campo comentarios
	if (comentarios.length > 50) {
		errorMensaje.innerHTML = "El campo comentarios no debe exceder los 50 caracteres";
		return false;
	} else {
		errorMensaje.innerHTML = "";
	}
    // Validar el campo password
    console.log(password);
    let comprobarPassword = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{6,}$/;
    console.log(comprobarPassword.test(password));
    if (!comprobarPassword.test(password)) {
        errorMensaje.innerHTML = "La contraseña debe tener una longitud mínima de 6 caracteres, y contener al menos una letra minúscula, una letra mayúscula y un dígito";
        return false;
    } else {
        errorMensaje.innerHTML = "";
}
	// Si todos los campos son válidos, mostrar un mensaje de éxito
	alert("¡El formulario se ha enviado correctamente!");
	return true;
}

function mostrarContrasena() {
	let mostrarPassword = document.getElementById("password");
	if (mostrarPassword.type === "password") {
		mostrarPassword.type = "text";
	} else {
		mostrarPassword.type = "password";
	}
}