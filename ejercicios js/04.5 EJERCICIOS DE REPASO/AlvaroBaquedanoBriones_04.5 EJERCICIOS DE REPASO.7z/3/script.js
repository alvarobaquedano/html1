function calcularMedia() {
    // Obtenemos las notas introducidas
    let nota1 = parseFloat(document.getElementById('nota1').value);
    let nota2 = parseFloat(document.getElementById('nota2').value);
    let nota3 = parseFloat(document.getElementById('nota3').value);

    // Calculamos la media
    let media = (nota1 + nota2 + nota3) / 3;

    // Mostramos la media en la página
    document.getElementById('media').innerHTML = '<h2>La media es: ' + media.toFixed(2) + '</h2>';
}