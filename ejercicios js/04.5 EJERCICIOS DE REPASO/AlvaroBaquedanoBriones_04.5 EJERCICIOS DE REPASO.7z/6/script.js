function comprobarPalindromo() {
    var cadena = document.getElementById("cadena").value.toLowerCase();
    var longitud = cadena.length;
    var mitad = Math.floor(longitud/2);

    for (var i = 0; i < mitad; i++) {
        if (cadena[i] !== cadena[longitud - 1 - i]) {
            document.getElementById("resultado").innerHTML = "La cadena no es un palíndromo";
            return false;
        }
    }
    document.getElementById("resultado").innerHTML = "La cadena es un palíndromo";
}