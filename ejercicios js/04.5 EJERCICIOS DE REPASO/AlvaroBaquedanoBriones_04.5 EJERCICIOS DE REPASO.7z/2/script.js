function contarVocales() {
    var frase = document.getElementById("frase").value;
    var vocales = frase.match(/[aeiou]/gi);
    var resultado = document.getElementById("resultado");
    if (vocales === null) {
        resultado.innerText = "No hay vocales en la frase";
    } else {
        resultado.innerText = vocales.join(", ");
    }
}