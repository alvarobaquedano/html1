function mostrarNumeroAleatorio() {
    let numero = Math.floor(Math.random() * 100) + 1; 
    alert("El número aleatorio es: " + numero);
}