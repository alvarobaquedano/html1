function cambiarImagen1(){
    document.getElementById("foto1").setAttribute("src","java.png");
}
function cambiarImagen2(){
    document.getElementById("foto2").setAttribute("src","java.png");
}
function cambiarImagen3(){
    document.getElementById("foto3").setAttribute("src","java.png");
}
function cambiarImagen4(){
    document.getElementById("foto4").setAttribute("src","java.png");
}
function recuperarImagen1(){
    document.getElementById("foto1").setAttribute("src","html.png");
}
function recuperarImagen2(){
    document.getElementById("foto2").setAttribute("src","css.png");
}
function recuperarImagen3(){
    document.getElementById("foto3").setAttribute("src","sql.png");
}
function recuperarImagen4(){
    document.getElementById("foto4").setAttribute("src","js.png");
}